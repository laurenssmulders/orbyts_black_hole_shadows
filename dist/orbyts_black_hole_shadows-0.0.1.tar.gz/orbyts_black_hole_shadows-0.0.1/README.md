# Testing gravity with Black Hole shadows
Relevant code for Orbyts project with year 10s testing alternative gravity theories using black hole shadows

# setup.py
import pathlib
from setuptools import setup

setup()